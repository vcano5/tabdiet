import './tabs.js'
import './icon.js'